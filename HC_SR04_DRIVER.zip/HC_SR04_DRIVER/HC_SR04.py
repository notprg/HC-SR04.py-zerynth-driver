from bsp import board
import gpio
import time
import adc  
            
echo=0
trigger=0

def init( echo_pin, trigger_pin ):
    global echo, trigger
    gpio.mode(echo_pin,INPUT)
    gpio.mode(trigger_pin,OUTPUT)
    echo = echo_pin
    trigger = trigger_pin
    
def getDistance() -> float:
    sleep(1000)
    gpio.high(trigger)
    sleep(10,MICROS)
    gpio.low(trigger)
    
    while gpio.get(echo) == 0:
        continue

    start = time.time() * 1000000
    while gpio.get(echo) == 1:
        continue
    stop = (time.time()*1000000)
    return ((stop - start)/58)
    