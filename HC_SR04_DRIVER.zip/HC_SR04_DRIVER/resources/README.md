# Hello Zerynth!

Welcome to the `resources` folder! Every file and directory you put here will be copied to the internal file system
of your Zerynth hardware.

If you want to disable this feature, just rename the `resources` folder to something else.

Enjoy!
